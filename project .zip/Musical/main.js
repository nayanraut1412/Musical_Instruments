function aa() {
  var audio = new Audio("/project /Musical/1cymbal .mp3");
  audio.play()
}

function bb() {
  var audio = new Audio("/project /Musical/2Piano.mp3");
  audio.play()
}

function cc() {
  var audio = new Audio("/project /Musical/3sitar.mp3");
  audio.play()
}

function dd() {
  var audio = new Audio("/project /Musical/4tabla.mp3");
  audio.play()
}

function ee() {
  var audio = new Audio("/project /Musical/5march.mp3");
  audio.play()
}

function ff() {
  var audio = new Audio("/project /Musical/6flute.mp3");
  audio.play()
}
function gg() {
  var audio = new Audio("/project /Musical/7guitar.mp3");
  audio.play()
}